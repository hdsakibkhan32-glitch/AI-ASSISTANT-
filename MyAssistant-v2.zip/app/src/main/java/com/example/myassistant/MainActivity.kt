package com.example.myassistant

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.AlarmClock
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    private val MODEL = "claude-sonnet-5-5"
    private lateinit var log: TextView
    private lateinit var input: EditText
    private lateinit var scroll: ScrollView
    private var tts: TextToSpeech? = null
    private val history = JSONArray()

    private val prefs get() = getSharedPreferences("assistant", MODE_PRIVATE)
    private val name get() = prefs.getString("name", "") ?: ""
    private val apiKey get() = prefs.getString("key", "") ?: ""

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContentView(R.layout.activity_main)
        log = findViewById(R.id.log); input = findViewById(R.id.input); scroll = findViewById(R.id.scroll)
        tts = TextToSpeech(this) { tts?.language = Locale("bn", "BD") }
        findViewById<Button>(R.id.send).setOnClickListener {
            val t = input.text.toString().trim()
            if (t.isNotEmpty()) { input.setText(""); ask(t) }
        }
        findViewById<Button>(R.id.mic).setOnClickListener { listen() }
        findViewById<Button>(R.id.settings).setOnClickListener { showSettings() }
        refreshTitle()
        if (name.isEmpty() || apiKey.isEmpty()) showSettings()
    }

    private fun refreshTitle() {
        findViewById<TextView>(R.id.title).text = if (name.isEmpty()) "আমার অ্যাসিস্ট্যান্ট" else name
    }

    private fun showSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 20, 40, 0) }
        val n = EditText(this).apply { hint = "অ্যাসিস্ট্যান্টের নাম"; setText(name) }
        val k = EditText(this).apply { hint = "Anthropic API Key"; setText(apiKey) }
        box.addView(n); box.addView(k)
        AlertDialog.Builder(this).setTitle("সেটিংস").setView(box)
            .setPositiveButton("সেভ") { _, _ ->
                prefs.edit().putString("name", n.text.toString().trim()).putString("key", k.text.toString().trim()).apply()
                refreshTitle()
            }.show()
    }

    private fun listen() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
        }
        try { startActivityForResult(i, 1) } catch (e: Exception) { show("ভয়েস ইনপুট পাওয়া যায়নি।") }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        super.onActivityResult(r, c, d)
        if (r == 1 && c == RESULT_OK) {
            d?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { ask(it) }
        }
    }

    private fun show(t: String) { log.append(t + "\n\n"); scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) } }

    private fun tools(): JSONArray {
        fun tool(n: String, d: String, props: JSONObject, req: List<String>) = JSONObject()
            .put("name", n).put("description", d)
            .put("input_schema", JSONObject().put("type", "object").put("properties", props).put("required", JSONArray(req)))
        fun p(type: String, desc: String) = JSONObject().put("type", type).put("description", desc)
        return JSONArray()
            .put(tool("set_alarm", "ফোনে অ্যালার্ম সেট করে (২৪ ঘণ্টার সময়)",
                JSONObject().put("hour", p("integer", "0-23")).put("minute", p("integer", "0-59")).put("label", p("string", "নাম")), listOf("hour", "minute")))
            .put(tool("set_timer", "কাউন্টডাউন টাইমার", JSONObject().put("seconds", p("integer", "সেকেন্ড")), listOf("seconds")))
            .put(tool("call_phone", "কল করার জন্য ডায়ালার খোলে নম্বর বসিয়ে", JSONObject().put("number", p("string", "ফোন নম্বর")), listOf("number")))
            .put(tool("send_sms", "SMS লিখে মেসেজ অ্যাপ খোলে", JSONObject().put("number", p("string", "নম্বর")).put("text", p("string", "বার্তা")), listOf("number", "text")))
            .put(tool("open_app", "নাম দিয়ে ইনস্টল করা অ্যাপ খোলে", JSONObject().put("app_name", p("string", "অ্যাপের নাম, যেমন YouTube")), listOf("app_name")))
            .put(tool("web_search", "ব্রাউজারে গুগল সার্চ করে", JSONObject().put("query", p("string", "সার্চ টেক্সট")), listOf("query")))
    }

    private fun ask(text: String) {
        show("আপনি: $text")
        history.put(JSONObject().put("role", "user").put("content", text))
        thread {
            try {
                val body = JSONObject().put("model", MODEL).put("max_tokens", 1000)
                    .put("system", "তুমি ${name.ifEmpty { "একটি" }} নামের ব্যক্তিগত অ্যাসিস্ট্যান্ট। ব্যবহারকারীর ভাষায় সংক্ষেপে উত্তর দাও। ফোনের কাজের জন্য টুল ব্যবহার করো।")
                    .put("tools", tools()).put("messages", history)
                val con = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
                con.requestMethod = "POST"; con.doOutput = true
                con.setRequestProperty("content-type", "application/json")
                con.setRequestProperty("x-api-key", apiKey)
                con.setRequestProperty("anthropic-version", "2023-06-01")
                con.outputStream.use { it.write(body.toString().toByteArray()) }
                val res = (if (con.responseCode < 400) con.inputStream else con.errorStream).bufferedReader().readText()
                val json = JSONObject(res)
                if (json.has("error")) throw Exception(json.getJSONObject("error").getString("message"))
                val content = json.getJSONArray("content")
                val reply = StringBuilder()
                for (i in 0 until content.length()) {
                    val b = content.getJSONObject(i)
                    if (b.getString("type") == "text") reply.append(b.getString("text"))
                    if (b.getString("type") == "tool_use") {
                        val msg = runOnUiThreadResult { runTool(b.getString("name"), b.getJSONObject("input")) }
                        if (reply.isEmpty()) reply.append(msg)
                    }
                }
                val out = reply.toString().ifEmpty { "ঠিক আছে।" }
                history.put(JSONObject().put("role", "assistant").put("content", out))
                runOnUiThread { show("${name.ifEmpty { "অ্যাসিস্ট্যান্ট" }}: $out"); tts?.speak(out, TextToSpeech.QUEUE_FLUSH, null, "a") }
            } catch (e: Exception) {
                history.remove(history.length() - 1)
                runOnUiThread { show("ত্রুটি: ${e.message}") }
            }
        }
    }

    private fun <T> runOnUiThreadResult(f: () -> T): T {
        var result: T? = null
        val lock = Object()
        runOnUiThread { result = f(); synchronized(lock) { lock.notifyAll() } }
        synchronized(lock) { while (result == null) lock.wait(200) }
        return result!!
    }

    private fun runTool(n: String, a: JSONObject): String {
        return try {
            when (n) {
                "set_alarm" -> {
                    startActivity(Intent(AlarmClock.ACTION_SET_ALARM)
                        .putExtra(AlarmClock.EXTRA_HOUR, a.getInt("hour")).putExtra(AlarmClock.EXTRA_MINUTES, a.getInt("minute"))
                        .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "অ্যালার্ম")).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                    "অ্যালার্ম সেট করেছি।"
                }
                "set_timer" -> {
                    startActivity(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, a.getInt("seconds")).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                    "টাইমার চালু করেছি।"
                }
                "call_phone" -> { startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + a.getString("number")))); "ডায়ালার খুলেছি, কল বাটনে চাপ দিন।" }
                "send_sms" -> {
                    startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + a.getString("number"))).putExtra("sms_body", a.getString("text")))
                    "মেসেজ তৈরি করেছি, পাঠাতে সেন্ড চাপুন।"
                }
                "open_app" -> {
                    val q = a.getString("app_name").lowercase()
                    val li = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                    val m = packageManager.queryIntentActivities(li, 0).firstOrNull { it.loadLabel(packageManager).toString().lowercase().contains(q) }
                    if (m != null) { startActivity(packageManager.getLaunchIntentForPackage(m.activityInfo.packageName)); "অ্যাপ খুলেছি।" } else "অ্যাপটি পাইনি।"
                }
                "web_search" -> { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(a.getString("query"))))); "সার্চ করছি।" }
                else -> "অজানা কাজ।"
            }
        } catch (e: Exception) { "কাজটি করতে পারিনি: ${e.message}" }
    }
}
