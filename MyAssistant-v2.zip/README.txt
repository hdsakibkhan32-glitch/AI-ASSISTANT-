কম্পিউটার ছাড়া APK বানানো (GitHub দিয়ে, বিনামূল্যে):
1. github.com-এ অ্যাকাউন্ট খুলুন, নতুন repository বানান।
2. এই zip-এর সব ফাইল (.github ফোল্ডারসহ) repository-তে আপলোড করুন।
3. Actions ট্যাবে "Build APK" চলতে দিন (৩-৫ মিনিট)।
4. শেষ হলে Artifacts থেকে MyAssistant-APK ডাউনলোড করে ফোনে ইনস্টল করুন।
5. অ্যাপ খুলে নাম ও API Key (console.anthropic.com) বসান।

কম্পিউটারে হলে: Android Studio-তে এই ফোল্ডার Open করে Run দিন।
